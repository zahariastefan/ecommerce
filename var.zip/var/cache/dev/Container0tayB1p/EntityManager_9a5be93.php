<?php

namespace Container0tayB1p;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder3297f = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerff768 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties93021 = [
        
    ];

    public function getConnection()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getConnection', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getMetadataFactory', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getExpressionBuilder', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'beginTransaction', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getCache', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getCache();
    }

    public function transactional($func)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'transactional', array('func' => $func), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'wrapInTransaction', array('func' => $func), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'commit', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->commit();
    }

    public function rollback()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'rollback', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getClassMetadata', array('className' => $className), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'createQuery', array('dql' => $dql), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'createNamedQuery', array('name' => $name), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'createQueryBuilder', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'flush', array('entity' => $entity), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'clear', array('entityName' => $entityName), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->clear($entityName);
    }

    public function close()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'close', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->close();
    }

    public function persist($entity)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'persist', array('entity' => $entity), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'remove', array('entity' => $entity), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'refresh', array('entity' => $entity), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'detach', array('entity' => $entity), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'merge', array('entity' => $entity), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getRepository', array('entityName' => $entityName), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'contains', array('entity' => $entity), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getEventManager', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getConfiguration', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'isOpen', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getUnitOfWork', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getProxyFactory', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'initializeObject', array('obj' => $obj), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'getFilters', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'isFiltersStateClean', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'hasFilters', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return $this->valueHolder3297f->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerff768 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder3297f) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder3297f = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder3297f->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, '__get', ['name' => $name], $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        if (isset(self::$publicProperties93021[$name])) {
            return $this->valueHolder3297f->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder3297f;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder3297f;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder3297f;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder3297f;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, '__isset', array('name' => $name), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder3297f;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder3297f;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, '__unset', array('name' => $name), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder3297f;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder3297f;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, '__clone', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        $this->valueHolder3297f = clone $this->valueHolder3297f;
    }

    public function __sleep()
    {
        $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, '__sleep', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;

        return array('valueHolder3297f');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerff768 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerff768;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerff768 && ($this->initializerff768->__invoke($valueHolder3297f, $this, 'initializeProxy', array(), $this->initializerff768) || 1) && $this->valueHolder3297f = $valueHolder3297f;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder3297f;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder3297f;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
